﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio_clase_producto
{
    class Program
    {
        static void Main(string[] args)
        {
            string id, desc;
            float precioUnitario;
            Producto ProductoMayor = new Producto();
            Producto aux;
            bool primeraIteracion = true;
            Console.WriteLine("Ingrese el ID de producto, 0 para finalizar");
            id = Console.ReadLine();
            while (id != "0")
            {
                Console.WriteLine("Ingrese la descripcion");
                desc = Console.ReadLine();
                Console.WriteLine("Ingrese el precio unitario");
                precioUnitario = float.Parse(Console.ReadLine());
                aux = new Producto(id,desc,precioUnitario);
                if (primeraIteracion == true)
                {
                    ProductoMayor = aux;
                    primeraIteracion = false;
                }
                else
                {
                    if (aux.compararCon(ProductoMayor) == 1)
                    {
                        ProductoMayor = aux;
                    }
                }
                Console.WriteLine("Ingrese el ID de producto, 0 para finalizar");
                id = Console.ReadLine();
            }
            if (primeraIteracion == true)
            {
                Console.WriteLine("No se ingresaron datos");
            }
            else
            {
                Console.WriteLine("Mostrando datos del producto mas caro");
                Console.WriteLine(ProductoMayor.mostrarDatos());
            }

            Console.ReadKey();
        }
    }
}
