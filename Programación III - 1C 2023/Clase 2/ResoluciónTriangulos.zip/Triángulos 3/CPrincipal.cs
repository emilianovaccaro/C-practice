﻿using System;

namespace Triángulos_3
{
    class CPrincipal
    {
        static void Main()
        {
            float l1, l2, l3, porcentaje;
            short triángulos, equi, esca, isos;
            triángulos = equi = esca = isos = 0;
            Console.Write("Ingrese Lado 1:");
            l1 = float.Parse(Console.ReadLine());
            Console.Write("Ingrese Lado 2:");
            l2 = float.Parse(Console.ReadLine());
            Console.Write("Ingrese Lado 3:");
            l3 = float.Parse(Console.ReadLine());
            while ((l1 > 0 && l2 > 0 && l3 > 0) && (l1 + l2 > l3 && l1 + l3 > l2 && l2 + l3 > l1))
            {
                triángulos++;
                if (l1 == l2 && l2 == l3)
                {
                    equi++;
                    Console.WriteLine("Triángulo Equilátero");
                }
                else
                {
                    if (l1 != l2 && l1 != l3 && l2 != l3)
                    {
                        esca++;
                        Console.WriteLine("Triángulo Escaleno");
                    }
                    else
                    {
                        isos++;
                        Console.WriteLine("Triángulo Isósceles");
                    }
                }

                Console.Write("Ingrese Lado 1:");
                l1 = float.Parse(Console.ReadLine());
                Console.Write("Ingrese Lado 2:");
                l2 = float.Parse(Console.ReadLine());
                Console.Write("Ingrese Lado 3:");
                l3 = float.Parse(Console.ReadLine());
            }
            Console.WriteLine("Triángulos válidos:{0}", triángulos);
            if (triángulos!=0)
            { 
                porcentaje = equi * 100 / triángulos;
                Console.WriteLine("Triángulos equiláteros:{0} ({1}%)", equi, porcentaje);
                porcentaje = esca * 100 / triángulos;
                Console.WriteLine("Triángulos escalenos:{0} ({1}%)", esca, porcentaje);
                porcentaje = isos * 100 / triángulos;
                Console.WriteLine("Triángulos isósceles:{0} ({1}%)", isos, porcentaje);
            }
        }
    }
}
