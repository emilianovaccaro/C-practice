﻿using System;

namespace Triángulos_2
{
    class Program
    {
        static void Main(string[] args)
        {
            float l1, l2, l3;
            Console.Write("Ingrese Lado 1:");
            l1 = float.Parse(Console.ReadLine());
            Console.Write("Ingrese Lado 2:");
            l2 = float.Parse(Console.ReadLine());
            Console.Write("Ingrese Lado 3:");
            l3 = float.Parse(Console.ReadLine());
            if ((l1>0 && l2>0 && l3> 0) && (l1 + l2 > l3 && l1 + l3 > l2 && l2 + l3 > l1))
            {
                if (l1 == l2 && l2 == l3)
                {
                    Console.WriteLine("Triángulo Equilátero");
                }
                else
                {
                    if (l1 != l2 && l1 != l3 && l2 != l3)
                    {
                        Console.WriteLine("Triángulo Escaleno");
                    }
                    else
                    {
                        Console.WriteLine("Triángulo Isósceles");
                    }
                }
            }
            else Console.WriteLine("Triángulo Inválido");
        }
    }
}
