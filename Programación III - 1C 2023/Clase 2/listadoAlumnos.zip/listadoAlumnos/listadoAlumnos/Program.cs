﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace listadoAlumnos
{
    class Program
    {
        static void Main(string[] args)
        {
            string apellido, apellidoMejorPromedio="";
            double promedio, mejorPromedio=0, promedioGeneral =0;
            int contAlumnos = 0, primerCiclo=0;
            const string finCiclo = "FIN";
            apellido = leerAlumno();
            while (apellido != finCiclo)
            {
                promedio = leerPromedio();
                contAlumnos++;
                promedioGeneral += promedio;
                if(primerCiclo == 0)
                {
                    primerCiclo = 1;
                    mejorPromedio = promedio;
                    apellidoMejorPromedio = apellido;
                }
                else
                {
                    if (promedio>mejorPromedio)
                    {
                        mejorPromedio = promedio;
                        apellidoMejorPromedio = apellido;
                    }
                }
                apellido = leerAlumno();
            }
            if (primerCiclo == 0)
            {
                Console.WriteLine("No se ingresaron alumnos");
            }
            else { 
            promedioGeneral = promedioGeneral / contAlumnos;
            Console.WriteLine("La cantidad de alumnos es {0}", contAlumnos);
            Console.WriteLine("El promedio general es {0}", promedioGeneral);
            Console.WriteLine("El mejor promedio es de {0} y pertenece a {1}", mejorPromedio, apellidoMejorPromedio);
            }
            Console.ReadKey();
        }
        static string leerAlumno()
        {
            string lectura;
            Console.WriteLine("Ingrese el apellido del alumno");
            lectura = Console.ReadLine();
            return lectura;
        }
        static double leerPromedio()
        {
            Console.WriteLine("Ingrese el promedio del alumno");
            return double.Parse(Console.ReadLine());
        }
    }
}
