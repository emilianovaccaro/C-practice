﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            float promedio, promedioGeneral, mejorPromedio =0, suma = 0;
            String apellido, apellidoMejorPromedio ="";
            bool primerCiclo = true;
            int contador = 0;

            apellido = leerApellido();
            while (apellido != "FIN")
            {
                bool op;
               
                do{
                 Console.WriteLine("Ingrese el promedio de {0}", apellido);
                 op= float.TryParse(Console.ReadLine(), out promedio);
                }
                while(op == false);
                //voy sumando el total y cuento los alumnos
                suma = suma + promedio;
                contador++;
                if (primerCiclo == true)
                {
                    mejorPromedio = promedio;
                    apellidoMejorPromedio = apellido;
                    primerCiclo = false;
                }
                else
                {
                    if (promedio > mejorPromedio)
                    {
                        mejorPromedio = promedio;
                        apellidoMejorPromedio = apellido;
                    }
                }

                apellido = leerApellido();
            }
            if (primerCiclo == true)
            {
                Console.WriteLine("No se ingresaron datos");
            }
            else
            {
                promedioGeneral = suma/contador;
                Console.WriteLine("El promedio general es de {0}", promedioGeneral);
                Console.WriteLine("El mejor promedio es de {0} y pertenece a {1}",mejorPromedio,apellidoMejorPromedio);
            }
            Console.Write("Ingrese una tecla para finalizar");
            Console.ReadKey();




        }

        static string leerApellido()
        {
            string apellido;
            Console.WriteLine("Ingrese un apellido o FIN para terminar");
            apellido = Console.ReadLine();
            return apellido;
        }

    }
}
