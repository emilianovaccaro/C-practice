﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_5_Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            int cantidadGoles, cantidadPartidos, cantAtajadas;
            long DNI;
            double maxPromedioGoles = 0, maxPromedioAtajadas = 0;
            string nombre, apellido, nombreMejorArquero = "undefined", nombreMejorJugador = "undefined";
            posicion posicion;
            bool primeraEntrada = true;
            DNI = leerLong("Ingrese un DNI. 0 para finalizar");
            while (DNI != 0)
            {
                nombre = leerCadena("Ingrese el nombre del jugador");
                apellido = leerCadena("Ingrese el apellido del jugador");
                posicion = leerPosicion("Ingrese la posicion. Arquero, Defensor, Mediocampista o Delantero");
                if(posicion == posicion.Arquero)
                {
                    cantAtajadas = leerEntero("Ingrese las atajadas del arquero");
                    cantidadPartidos = leerEntero("Ingrese la cantidad de partidos del arquero");
                    if (primeraEntrada == true)
                    {
                        maxPromedioAtajadas = cantAtajadas / cantidadPartidos;
                        nombreMejorArquero = nombre;
                        primeraEntrada = false;

                    }
                    else
                    {
                        double dif = compararPromedios(maxPromedioAtajadas, cantAtajadas / cantidadPartidos);
                        if (dif < 0)
                        {
                            maxPromedioAtajadas = cantAtajadas / cantidadPartidos;
                            nombreMejorArquero = nombre;
                        }
                    }
                }
                else
                {
                    cantidadGoles = leerEntero("Ingrese la cantidad de goles del jugador");
                    cantidadPartidos = leerEntero("Ingrese la cantidad de partidos");
                    if(primeraEntrada == true)
                    {
                        maxPromedioGoles = cantidadGoles / cantidadPartidos;
                        nombreMejorJugador = nombre;
                        primeraEntrada = false;
                    }
                    else
                    {
                        double dif = compararPromedios(maxPromedioGoles, cantidadGoles / cantidadPartidos);
                        if (dif < 0)
                        {
                            maxPromedioGoles = cantidadGoles / cantidadPartidos;
                            nombreMejorJugador = nombre;
                        }
                    }

                }
                DNI = leerLong("Ingrese un DNI. 0 para finalizar");
            }
            if(primeraEntrada == true)
            {
                mostrarMensaje("no se ingresaron datos");
            }
            else
            {
                mostrarMensaje("El mejor arquero fue " + nombreMejorArquero + " con un promedio de " + maxPromedioAtajadas.ToString());
                mostrarMensaje("El mejor jugador fue " + nombreMejorJugador + " con un promedio de " + maxPromedioGoles.ToString());
            }
            mostrarMensaje("Ingrese una tecla para continuar");
            Console.ReadKey();

        }
        static int compararGoles(int max, int nuevo)
        {
            return max - nuevo; //devuevle 0 si son iguales, mayor a 0 si el nuevo es menor y menor a 0 si el nuevo es mayor
        }
        static double compararPromedios (double max, double nuevo)
        {
            return max - nuevo;
        }
        static int leerEntero(string mensaje)
        {
            int lectura;
            
            bool resultado;
            do
            {
                mostrarMensaje(mensaje);
                resultado = int.TryParse(Console.ReadLine(), out lectura);
            } while (resultado == false);
            return lectura;
            
        }
        static long leerLong(string mensaje)
        {
            long lectura;

            bool resultado;
            do
            {
                mostrarMensaje(mensaje);
                resultado = long.TryParse(Console.ReadLine(), out lectura);
            } while (resultado == false);
            return lectura;
        }
        static double leerDouble (string mensaje)
        {
            double lectura;

            bool resultado;
            do
            {
                mostrarMensaje(mensaje);
                resultado = double.TryParse(Console.ReadLine(), out lectura);
            } while (resultado == false);
            return lectura;
        }
        static string leerCadena(string mensaje)
        {
            mostrarMensaje(mensaje);
            return Console.ReadLine();
        }
        static posicion leerPosicion(string mensaje)
        {
            posicion dato = posicion.Arquero;
            bool correcto = false;
            do
            {
                string lectura = leerCadena(mensaje);
                switch (lectura)
                {
                    case "Arquero":
                        dato = posicion.Arquero;
                        correcto = true;
                        break;
                    case "Defensor":
                        dato = posicion.Defensor;
                        correcto = true;
                        break;
                    case "Mediocampista":
                        dato = posicion.Mediocampista;
                        correcto = true;
                        break;
                    case "Delanter":
                        dato = posicion.Delantero;
                        correcto = true;
                        break;
                    default:
                        correcto = false;
                        break;
                }
            } while (correcto == false);
            return dato;
      }
       static void mostrarMensaje(string mensaje)
        {
            Console.WriteLine(mensaje);
        }

    }
}
