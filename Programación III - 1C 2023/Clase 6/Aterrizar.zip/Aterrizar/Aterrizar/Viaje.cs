﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aterrizar
{
    class Viaje
    {
        string codigo;
        string origen;
        string destino;
 //       float precio;

        public Viaje(string codigo, string origen, string destino)
        {
            this.codigo = codigo;
            this.origen = origen;
            this.destino = destino;
        }
        public float precio { get; set; }
        public string getCodigo()
        {
            return this.codigo;
        }
        public float darPrecio(int cuotas)
        {
            float precioFinal;
            switch (cuotas)
            {
                case 1:
                    precioFinal = precio;
                break;
            case 3:
                precioFinal = precio + precio * 0.1f;
                break;
                case 6:
                precioFinal = precio + precio * 0.2f;
                break;
                case 12:
                precioFinal = precio + precio * 0.4f;
                break;
                default:
                precioFinal = -1;
                break;
            }
            return precioFinal;
        }
        public string darDatos()
        {
            return "Codigo: " + this.codigo + "Origen: " + this.origen + "Destino: " + this.destino + "Precio: " + this.precio;
        }
    }
}
