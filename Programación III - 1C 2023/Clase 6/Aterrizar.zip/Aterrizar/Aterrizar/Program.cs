﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aterrizar
{
    class Program
    {
        static void Main(string[] args)
        {
            const int cantViajes = 3;
            int i,cantCuotas;
            string codigo, origen, destino;
            float precio,precioFinal;
            Viaje[] viajes = new Viaje[cantViajes];
            Console.WriteLine("Carga de datos de viajes");
            Console.WriteLine("----------------------------------");
            for (i = 0; i < cantViajes; i++)
            {
                Console.WriteLine("Ingrese el codigo");
                codigo = Console.ReadLine();
                Console.WriteLine("Ingrese el origen");
                origen = Console.ReadLine();
                Console.WriteLine("Ingrese el destino");
                destino = Console.ReadLine();
                Console.WriteLine("Ingrese el precio");
                precio = float.Parse(Console.ReadLine());
                viajes[i] = new Viaje(codigo,origen,destino);
                viajes[i].precio = precio;
            }
            Console.WriteLine("Carga de datos de viajes finalizada");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("Ingrese un codigo, FIN para finalizar");
            codigo = Console.ReadLine();
            while(codigo!="FIN")
            {
                int posicion =buscar(viajes, codigo);
                if (posicion < 0)
                {
                    Console.WriteLine("No se encontro el viaje");
                }
                else
                {
                    Console.WriteLine(viajes[posicion].darDatos());
                    Console.WriteLine("Ingrese la cantidad de cuotas");
                    cantCuotas = int.Parse(Console.ReadLine());
                    precioFinal = viajes[posicion].darPrecio(cantCuotas);
                    if (precioFinal < 0)
                    {
                        Console.WriteLine("Cantidad de cuotas incorrecta");
                    }
                    else
                    {
                        Console.WriteLine("El precio final + intereses es {0}",precioFinal);
                    }

                }
                Console.WriteLine("Ingrese un codigo, FIN para finalizar");
                codigo = Console.ReadLine();
            }
        }

        static int buscar(Viaje[] viajes, string codigo)
        {
            //int encontrado = -1;
            for (int i = 0; i < viajes.Length; i++)
            {
                if (viajes[i].getCodigo() == codigo)
                {
                    return i;
                }
            }
            return -1;
        }
    }
}
