﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace clase5Ej2
{
    class Program
    {
        static void Main(string[] args)
        {
            Cuenta[] cuentas;
            cuentas = new Cuenta[50];
            int contador=0;
            ulong CBU;
            string cliente;
            float saldo;
            float monto;
            CBU = leerCBU();

            /*Ingreso de datos */
            while(contador <50 && CBU!= 0 )
            {
                cliente = leerNombre();
                saldo = leerSaldo();
                cuentas[contador] = new Cuenta(CBU,cliente,saldo);
                contador++;
                CBU = leerCBU();
            }
            /*fin de carga de datos*/
            Console.WriteLine("Fin de carga de datos. Ahora puede consultar");
            CBU = leerCBU();
            while(CBU !=0)
            {

                int indiceCBU = buscar(cuentas,CBU);
                if (indiceCBU <0)
                {
                    Console.WriteLine("No se encontro el CBU {0}", CBU);
                }
                else
                {
                    int accion = menu();

                    switch (accion)
                    {
                        case 1:
                            Console.WriteLine("ingrese el monto");
                            monto = float.Parse(Console.ReadLine());
                            if (cuentas[indiceCBU].depositar(monto))
                            {
                                Console.WriteLine("Deposito correcto");
                            }
                            else
                            {
                                Console.WriteLine("fallo el deposito");
                            }
                            break;
                        case 2:
                            Console.WriteLine("ingrese el monto");
                            monto = float.Parse(Console.ReadLine());
                            if (cuentas[indiceCBU].extraer(monto))
                            {
                                Console.WriteLine("Extraccion correcta");
                            }
                            else
                            {
                                Console.WriteLine("fallo la extraccion");
                            }
                            break;
                        case 3:
                            Console.WriteLine(cuentas[indiceCBU].darDatos());
                            break;
                    }

                }
                CBU = leerCBU();
            }
            Console.Clear();
            Console.WriteLine("Mostrando valores finales de las cuentas");
            int cont =0;
            while(cuentas[cont]!=null){
                Console.WriteLine(cuentas[cont].darDatos());
                cont++;
            }
            Console.ReadKey();
        }

        private static int buscar(Cuenta[] cuentas,ulong CBU)
        {
            for (int i = 0; i < cuentas.Length; i++)
            {
                if(CBU == cuentas[i].getCBU())
                {
                    return i;
                }
            }
            return -1;
        }

        private static int menu()
        {
            int opcionElegida = 0;
            do
            {
                Console.WriteLine("Elija una opcion para el CBU ingresado");
                Console.WriteLine("1 - Realizar un deposito");
                Console.WriteLine("2 - Realizar una extraccion");
                Console.WriteLine("3 - Ver datos");
                opcionElegida = int.Parse(Console.ReadLine());
            } while (opcionElegida > 3 || opcionElegida < 1);
            return opcionElegida;
        }
        static ulong leerCBU()
        {
            Console.WriteLine("Ingrese el CBU");
            return ulong.Parse(Console.ReadLine());
        }
        static string leerNombre()
        {
            Console.WriteLine("Ingrese el Nombre");
            return Console.ReadLine();
        }
        static float leerSaldo()
        {
            Console.WriteLine("Ingrese el Saldo");
            return float.Parse(Console.ReadLine());
        }
    }
}
