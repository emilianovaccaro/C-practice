﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace claseCuentaIntro
{
    class Program
    {
        static void Main(string[] args)
        {
            ulong CBU;
            string nombre;
            float saldo;
            Cuenta nueva;

            Console.WriteLine("Ingrese el CBU");
            CBU = ulong.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el nombre");
            nombre = Console.ReadLine();

            nueva = new Cuenta(CBU, nombre);

            Console.WriteLine("Datos iniciales de cuenta: ");
            Console.WriteLine(nueva.darDatos());

            Console.WriteLine("Ingrese un monto a depositar");
            float monto = float.Parse(Console.ReadLine());

            if (nueva.depositar(monto) == false)
            {
                salir("fallo el deposito");
            }

            Console.WriteLine("Ingrese un monto a extraer");
            monto = float.Parse(Console.ReadLine());
            if (nueva.extraer(monto) == false)
            {
                salir("Fallo la extraccion");
            }

            Console.WriteLine("Datos finales de cuenta: ");
            Console.WriteLine(nueva.darDatos());
            Console.ReadKey();
        }

        public static void salir(string mensaje)
        {
            Console.WriteLine(mensaje);
            Console.ReadKey();
            return;
        }

    }
}
